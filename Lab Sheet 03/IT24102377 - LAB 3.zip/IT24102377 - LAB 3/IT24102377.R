setwd("C:\\Users\\it24102377\\Desktop\\IT24102377 - LAB 3")

student_data <- read.csv("C:\\Users\\it24102377\\Desktop\\IT24102377 - LAB 3\\Exercise.csv")
head(student_data)

# Summary statistics
summary(student_data$X1)
# Basic histogram
hist(student_data$X1,
     main = "Histogram of Age",
     xlab = "Age",
     col = "skyblue",
     border = "black")

# Frequency table
table(student_data$X2)
# Bar chart
barplot(table(student_data$X2),
        main = "Gender Distribution",
        xlab = "Gender",
        ylab = "Frequency",
        col = c("lightblue", "pink"))

# Basic boxplot
boxplot(X1 ~ X3,
        data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightgreen", "lightblue", "lightpink"))
